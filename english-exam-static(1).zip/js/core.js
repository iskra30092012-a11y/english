/* English Exam — статическая сборка.
   Общие модули: локальное хранилище, озвучка (Web Speech API), мелкие помощники.
   Никаких сборщиков, импортов и сетевых запросов: обычный браузерный JavaScript. */
(function () {
  'use strict';

  var EE = (window.EE = window.EE || {});
  var DATA = (EE.data = window.EE_DATA || { exams: {}, curriculum: {}, exercises: {}, speed: {}, tasks: {}, topics: {}, trainers: [], skillFormats: [], dictionarySeed: {} });

  /* ------------------------------------------------------------------ */
  /* helpers                                                             */
  /* ------------------------------------------------------------------ */
  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (key) {
        var value = attrs[key];
        if (value === null || value === undefined || value === false) return;
        if (key === 'class') node.className = value;
        else if (key === 'html') node.innerHTML = value;
        else if (key === 'text') node.textContent = value;
        else if (key.indexOf('on') === 0 && typeof value === 'function') node.addEventListener(key.slice(2), value);
        else node.setAttribute(key, value === true ? '' : value);
      });
    }
    (children || []).forEach(function (child) {
      if (child === null || child === undefined) return;
      node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child);
    });
    return node;
  }
  function clear(node) { while (node && node.firstChild) node.removeChild(node.firstChild); }
  function esc(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function shuffle(list) {
    var copy = list.slice();
    for (var i = copy.length - 1; i > 0; i -= 1) {
      var j = Math.floor(Math.random() * (i + 1));
      var tmp = copy[i]; copy[i] = copy[j]; copy[j] = tmp;
    }
    return copy;
  }
  function words(text) { return String(text || '').trim().split(/\s+/).filter(Boolean).length; }
  function pct(part, total) { return total > 0 ? Math.round((part / total) * 100) : 0; }
  function todayKey() { return new Date().toISOString().slice(0, 10); }

  EE.el = el; EE.clear = clear; EE.esc = esc; EE.shuffle = shuffle; EE.words = words; EE.pct = pct;
  EE.trainerById = function (id) {
    return (DATA.trainers || []).filter(function (item) { return item.id === id; })[0] || null;
  };

  /* ------------------------------------------------------------------ */
  /* store: весь прогресс живёт в localStorage этого браузера             */
  /* ------------------------------------------------------------------ */
  var KEY = 'ee-static:state-v1';
  var emptyState = function () {
    return {
      version: 1,
      exam: 'oge',
      completed: {},      // "oge:grammar" -> [ids]
      wrong: [],          // {exam, trainer, id, prompt, answer, given, explanation, at}
      attempts: [],       // {exam, trainer, correct, total, at, minutes}
      activity: {},       // "2026-11-23" -> минуты
      dictionary: { oge: [], ege: [] },
      drafts: {},         // "oge:writing:taskId" -> текст
      done: {}            // отмеченные открытые задания
    };
  };

  var Store = {
    state: emptyState(),
    listeners: [],
    load: function () {
      try {
        var raw = window.localStorage.getItem(KEY);
        if (raw) {
          var parsed = JSON.parse(raw);
          if (parsed && typeof parsed === 'object') {
            var base = emptyState();
            Object.keys(base).forEach(function (key) { if (parsed[key] === undefined) parsed[key] = base[key]; });
            this.state = parsed;
          }
        }
      } catch (error) { this.state = emptyState(); }
      return this.state;
    },
    save: function () {
      try { window.localStorage.setItem(KEY, JSON.stringify(this.state)); } catch (error) { /* приватный режим */ }
      this.listeners.forEach(function (fn) { try { fn(Store.state); } catch (error) {} });
    },
    on: function (fn) { this.listeners.push(fn); },
    reset: function () {
      this.state = emptyState();
      try { window.localStorage.removeItem(KEY); } catch (error) {}
      this.save();
    },
    completedIds: function (exam, trainer) {
      return this.state.completed[exam + ':' + trainer] || [];
    },
    markCompleted: function (exam, trainer, id) {
      var key = exam + ':' + trainer;
      var list = this.state.completed[key] || (this.state.completed[key] = []);
      if (list.indexOf(id) === -1) list.push(id);
      this.save();
    },
    addWrong: function (record) {
      var list = this.state.wrong.filter(function (item) {
        return !(item.exam === record.exam && item.trainer === record.trainer && item.id === record.id);
      });
      list.unshift(record);
      this.state.wrong = list.slice(0, 300);
      this.save();
    },
    addAttempt: function (exam, trainer, correct, total, minutes) {
      this.state.attempts.unshift({ exam: exam, trainer: trainer, correct: correct, total: total, at: new Date().toISOString(), minutes: minutes || 0 });
      this.state.attempts = this.state.attempts.slice(0, 200);
      if (minutes) this.addMinutes(minutes);
      this.save();
    },
    addMinutes: function (minutes) {
      var key = todayKey();
      this.state.activity[key] = (this.state.activity[key] || 0) + Math.max(1, Math.round(minutes));
      this.save();
    },
    streak: function () {
      var days = Object.keys(this.state.activity).sort();
      if (!days.length) return 0;
      var streak = 0;
      var cursor = new Date();
      for (var i = 0; i < 400; i += 1) {
        var key = cursor.toISOString().slice(0, 10);
        if (this.state.activity[key]) { streak += 1; cursor.setDate(cursor.getDate() - 1); }
        else if (i === 0) { cursor.setDate(cursor.getDate() - 1); }
        else break;
      }
      return streak;
    },
    totals: function () {
      var attempts = this.state.attempts;
      var correct = attempts.reduce(function (sum, item) { return sum + item.correct; }, 0);
      var total = attempts.reduce(function (sum, item) { return sum + item.total; }, 0);
      var minutes = Object.keys(this.state.activity).reduce(function (sum, key) { return sum + this.state.activity[key]; }, 0);
      return { rounds: attempts.length, correct: correct, total: total, minutes: minutes, accuracy: total ? Math.round((correct / total) * 100) : null };
    }
  };
  EE.Store = Store;

  /* ------------------------------------------------------------------ */
  /* speech: озвучка английского текста голосом браузера                 */
  /* ------------------------------------------------------------------ */
  var VOICE_KEY = 'ee-static:tts-voice';
  var RATE_KEY = 'ee-static:tts-rate';
  var NO_VOICE_NOTICE = 'На устройстве не найден английский голос. Добавь английский язык в настройках системы (Windows: «Язык и регион» → «Речь»; macOS/iOS: «Универсальный доступ» → «Устный контент»; Android: «Настройки» → «Синтез речи»).';

  function chunkText(text) {
    var sentences = String(text || '').replace(/\s+/g, ' ').match(/[^.!?;:]+[.!?;:]?/g) || [String(text || '')];
    var chunks = []; var buffer = '';
    sentences.forEach(function (sentence) {
      if ((buffer + sentence).length > 180 && buffer) { chunks.push(buffer.trim()); buffer = sentence; }
      else buffer += sentence;
    });
    if (buffer.trim()) chunks.push(buffer.trim());
    return chunks.length ? chunks : [String(text || '')];
  }

  function englishVoices() {
    if (!window.speechSynthesis || !window.speechSynthesis.getVoices) return [];
    return window.speechSynthesis.getVoices().filter(function (voice) { return /^en(-|_)?/i.test(voice.lang || ''); });
  }

  /** Возвращает DOM-блок плеера для переданного текста. */
  function speechControl(text, options) {
    options = options || {};
    var supported = typeof window !== 'undefined' && 'speechSynthesis' in window && typeof window.SpeechSynthesisUtterance === 'function';
    var chunks = chunkText(text);
    var state = { status: 'idle', index: 0, voices: [], voiceURI: '', rate: 0.95, notice: '' };
    try { state.voiceURI = window.localStorage.getItem(VOICE_KEY) || ''; } catch (error) {}
    try { state.rate = Number(window.localStorage.getItem(RATE_KEY)) || 0.95; } catch (error) {}

    var wrap = el('div', { class: 'speech' + (options.compact ? ' speech-compact' : '') });
    var controls = el('div', { class: 'speech-controls' });
    var playBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm speech-play' });
    var stopBtn = el('button', { type: 'button', class: 'speech-icon', title: 'Остановить', 'aria-label': 'Остановить озвучку', html: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>' });
    var settingsBtn = el('button', { type: 'button', class: 'speech-icon', title: 'Голос и скорость', 'aria-label': 'Настройки голоса', html: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M4 12h2M18 12h2M12 4v2M12 18v2M6.3 6.3l1.4 1.4M16.3 16.3l1.4 1.4M17.7 6.3l-1.4 1.4M7.7 16.3l-1.4 1.4"/></svg>' });
    var status = el('span', { class: 'speech-status', 'aria-live': 'polite' });
    var settings = el('div', { class: 'speech-settings', hidden: 'hidden' });
    var notice = el('div', { class: 'speech-notice', hidden: 'hidden', role: 'status' });

    controls.appendChild(playBtn); controls.appendChild(stopBtn); controls.appendChild(settingsBtn); controls.appendChild(status);
    wrap.appendChild(controls); wrap.appendChild(settings); wrap.appendChild(notice);

    function selectedVoice() {
      if (!state.voices.length) return null;
      var match = state.voices.filter(function (voice) { return voice.voiceURI === state.voiceURI; })[0];
      if (match) return match;
      var gb = state.voices.filter(function (voice) { return /^en-GB/i.test(voice.lang); })[0];
      return gb || state.voices[0];
    }
    function paint() {
      var label = options.label || 'Прослушать';
      playBtn.textContent = state.status === 'speaking' ? 'Пауза' : state.status === 'paused' ? 'Продолжить' : label;
      playBtn.setAttribute('aria-label', state.status === 'speaking' ? 'Пауза' : state.status === 'paused' ? 'Продолжить чтение' : label);
      playBtn.classList.toggle('is-active', state.status === 'speaking');
      stopBtn.disabled = state.status === 'idle';
      status.textContent = state.status === 'speaking' ? 'Читаю…' : state.status === 'paused' ? 'Пауза' : '';
      notice.hidden = !state.notice;
      notice.textContent = state.notice;
      settings.hidden = !settingsOpen;
      settingsBtn.classList.toggle('is-active', settingsOpen);
    }
    var settingsOpen = false;

    function speakFrom(index) {
      if (!supported) return;
      window.speechSynthesis.cancel();
      var current = Math.max(0, Math.min(index, chunks.length - 1));
      state.index = current;
      var voice = selectedVoice();

      function speakChunk() {
        var chunk = chunks[current];
        if (chunk === undefined) { state.status = 'idle'; state.index = 0; paint(); return; }
        var utterance = new window.SpeechSynthesisUtterance(chunk);
        utterance.lang = (voice && voice.lang) || 'en-GB';
        if (voice) utterance.voice = voice;
        utterance.rate = state.rate;
        utterance.pitch = 1;
        utterance.onend = function () {
          current += 1; state.index = current;
          if (current < chunks.length) speakChunk();
          else { state.status = 'idle'; state.index = 0; paint(); }
        };
        utterance.onerror = function (event) {
          state.status = 'idle';
          if (event && (event.error === 'interrupted' || event.error === 'canceled')) { paint(); return; }
          state.notice = event && event.error === 'not-allowed'
            ? 'Браузер заблокировал озвучивание. Нажми кнопку ещё раз — на iOS и Android запуск возможен только по касанию.'
            : 'Не удалось озвучить текст. Попробуй другой голос или браузер.';
          paint();
        };
        try { window.speechSynthesis.speak(utterance); } catch (error) {
          state.notice = 'Не удалось озвучить текст. Попробуй другой голос или браузер.';
          state.status = 'idle'; paint();
        }
      }
      state.notice = '';
      state.status = 'speaking';
      paint();
      speakChunk();
    }

    function play() {
      if (!supported) {
        state.notice = 'Этот браузер не поддерживает озвучивание. Используй Chrome, Safari, Edge или Firefox последней версии.';
        paint(); return;
      }
      if (!String(text || '').trim()) return;
      var missing = state.voices.length ? '' : NO_VOICE_NOTICE;
      if (state.status === 'paused') {
        if (window.speechSynthesis.paused) {
          window.speechSynthesis.resume();
          state.status = 'speaking';
        } else speakFrom(state.index);
        if (missing) state.notice = missing;
        paint(); return;
      }
      speakFrom(0);
      if (missing) { state.notice = missing; paint(); }
    }
    function pause() {
      if (!supported || state.status !== 'speaking') return;
      try { window.speechSynthesis.pause(); } catch (error) {}
      state.status = 'paused';
      if (!window.speechSynthesis.speaking) state.notice = 'Пауза недоступна в этом браузере — используй «Стоп» и запусти чтение снова.';
      paint();
    }
    function stop() {
      if (!supported) return;
      try { window.speechSynthesis.cancel(); } catch (error) {}
      state.index = 0; state.status = 'idle'; state.notice = '';
      paint();
    }

    playBtn.addEventListener('click', function () { if (state.status === 'speaking') pause(); else play(); });
    stopBtn.addEventListener('click', stop);
    settingsBtn.addEventListener('click', function () {
      settingsOpen = !settingsOpen;
      refreshVoices();
      paint();
    });

    function refreshVoices() {
      state.voices = englishVoices();
      clear(settings);
      var select = el('select', { 'aria-label': 'Английский голос' });
      if (!state.voices.length) select.appendChild(el('option', { value: '', text: 'Английский голос не найден' }));
      state.voices.forEach(function (voice) {
        select.appendChild(el('option', { value: voice.voiceURI, text: voice.name + ' · ' + voice.lang }));
      });
      select.value = (selectedVoice() || {}).voiceURI || '';
      select.disabled = !state.voices.length;
      select.addEventListener('change', function () {
        state.voiceURI = select.value;
        try { window.localStorage.setItem(VOICE_KEY, select.value); } catch (error) {}
        if (state.status === 'speaking') speakFrom(state.index);
      });
      var rate = el('input', { type: 'range', min: '0.6', max: '1.3', step: '0.05', value: String(state.rate), 'aria-label': 'Скорость чтения' });
      var rateValue = el('b', { text: state.rate.toFixed(2) + '×' });
      rate.addEventListener('input', function () {
        state.rate = Number(rate.value);
        rateValue.textContent = state.rate.toFixed(2) + '×';
        try { window.localStorage.setItem(RATE_KEY, String(state.rate)); } catch (error) {}
        if (state.status === 'speaking') speakFrom(state.index);
      });
      settings.appendChild(el('label', {}, [el('span', { text: 'Голос' }), select]));
      settings.appendChild(el('label', {}, [el('span', { text: 'Скорость' }), rate, rateValue]));
    }

    if (supported) {
      refreshVoices();
      window.speechSynthesis.addEventListener('voiceschanged', function () { refreshVoices(); });
      window.setTimeout(refreshVoices, 300);
      window.setTimeout(refreshVoices, 1200);
    }
    paint();
    return wrap;
  }
  EE.speechControl = speechControl;

  /* ------------------------------------------------------------------ */
  /* общие куски разметки                                                */
  /* ------------------------------------------------------------------ */
  EE.badge = function (text, tone) { return el('span', { class: 'badge badge-' + (tone || 'neutral'), text: text }); };
  EE.progress = function (value) {
    return el('div', { class: 'bar' }, [el('i', { style: 'width:' + Math.max(0, Math.min(100, Math.round(value))) + '%' })]);
  };
  EE.card = function (children, extraClass) { return el('section', { class: 'card' + (extraClass ? ' ' + extraClass : '') }, children); };
  EE.emptyState = function (title, text, action) {
    return el('div', { class: 'empty' }, [el('h3', { text: title }), el('p', { text: text })].concat(action ? [action] : []));
  };
  EE.examLabel = function (exam) { return exam === 'ege' ? 'ЕГЭ' : 'ОГЭ'; };
  EE.examTone = function (exam) { return exam === 'ege' ? 'violet' : 'blue'; };

  /* ---------------------------------------------------------------- */
  /* навигация: подсветка текущей страницы                              */
  /* ---------------------------------------------------------------- */
  document.addEventListener('DOMContentLoaded', function () {
    Store.load();
    var page = document.body.getAttribute('data-page');
    Array.prototype.forEach.call(document.querySelectorAll('[data-nav]'), function (link) {
      if (link.getAttribute('data-nav') === page) link.classList.add('is-current');
    });
  });
})();
