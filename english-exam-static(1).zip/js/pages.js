/* English Exam — статическая сборка: контроллеры страниц.
   Каждая страница — отдельный HTML-файл; этот файл только оживляет её разметку. */
(function () {
  'use strict';

  var EE = window.EE;
  var DATA = EE.data;
  var el = EE.el, clear = EE.clear, Store = EE.Store;

  function mount(name) {
    var node = document.querySelector('[data-mount="' + name + '"]');
    return node || null;
  }
  function text(value) { return document.createTextNode(String(value)); }

  /* ------------------------------------------------------------------ */
  /* переключатель ОГЭ / ЕГЭ                                             */
  /* ------------------------------------------------------------------ */
  function examSwitch(exam, onChange, options) {
    options = options || {};
    var wrap = el('div', { class: 'exam-switch', role: 'group', 'aria-label': 'Выбор экзамена' });
    ['oge', 'ege'].forEach(function (code) {
      var btn = el('button', {
        type: 'button',
        class: 'exam-switch-btn' + (code === exam ? ' is-active ' + code : ''),
        'aria-pressed': code === exam ? 'true' : 'false',
        text: EE.examLabel(code)
      });
      btn.addEventListener('click', function () {
        if (code === exam) return;
        if (options.persist !== false) { Store.state.exam = code; Store.save(); }
        onChange(code);
      });
      wrap.appendChild(btn);
    });
    return wrap;
  }

  function sectionLabel(section) {
    return ({ grammar: 'Грамматика', vocabulary: 'Лексика', wordformation: 'Словообразование', tenses: 'Времена', reading: 'Чтение', listening: 'Аудирование', 'find-error': 'Найди ошибку', speed: 'Скорость' })[section] || section;
  }

  function trainerLink(trainerId, exam, label) {
    return el('a', { class: 'btn btn-ghost btn-sm', href: './' + trainerId + '.html', text: label || 'Открыть тренажёр' });
  }

  function pageOf(trainerId) { return 'trainer-' + trainerId + '.html'; }
  EE.pageOf = pageOf;

  /* ------------------------------------------------------------------ */
  /* пул заданий                                                         */
  /* ------------------------------------------------------------------ */
  function poolFor(exam, trainer) {
    if (trainer === 'speed') return (DATA.speed[exam] || []);
    var section = trainer === 'wordformation' ? 'wordformation' : trainer;
    var bank = DATA.exercises[exam] || [];
    return bank.filter(function (item) { return item.section === section; });
  }

  function audioPath(exercise) {
    if (!exercise.audioFile) return '';
    return './' + String(exercise.audioFile).replace(/^\.?\//, '');
  }

  /* ------------------------------------------------------------------ */
  /* плеер: аудиофайл либо озвучка браузера                              */
  /* ------------------------------------------------------------------ */
  function listeningPlayer(exercise, revealTranscript) {
    var box = el('div', { class: 'listening-box' });
    var src = audioPath(exercise);
    if (src) {
      box.appendChild(el('audio', { controls: 'controls', preload: 'metadata', src: src, 'aria-label': 'Аудиозапись задания' }));
      box.appendChild(el('p', { class: 'hint', text: 'Синтезированная запись этого проекта — не официальная аудиозапись ФИПИ.' }));
    } else if (exercise.passage) {
      box.appendChild(el('div', { class: 'listening-browser' }, [
        EE.speechControl(exercise.passage, { compact: true, label: 'Прослушать текст' }),
        el('p', { class: 'hint', text: 'Запись к этому набору не приложена: текст читает голос браузера. Это не официальная аудиозапись ФИПИ.' })
      ]));
    }
    if (revealTranscript && exercise.passage) {
      var details = el('details', { class: 'transcript' }, [
        el('summary', { text: 'Показать текст записи' }),
        el('p', { text: exercise.passage })
      ]);
      box.appendChild(details);
    }
    return box;
  }

  /* ------------------------------------------------------------------ */
  /* квиз-движок (find-error, speed, grammar, vocabulary, wordformation,  */
  /* tenses, reading, listening)                                         */
  /* ------------------------------------------------------------------ */
  function quizTrainer(root, exam, trainerId) {
    var state = {
      exam: exam,
      trainer: trainerId,
      difficulty: 'all',
      order: 'shuffle',
      session: null,
      index: 0,
      answers: {},
      checked: false,
      finished: false,
      timeLeft: 60,
      timer: null,
      startedAt: 0
    };
    var speed = trainerId === 'speed';

    function pool() {
      var base = poolFor(state.exam, state.trainer);
      return state.difficulty === 'all' ? base : base.filter(function (item) { return item.difficulty === Number(state.difficulty); });
    }

    function render() {
      clear(root);
      if (!state.session) { root.appendChild(startScreen()); return; }
      if (state.finished) { root.appendChild(resultScreen()); return; }
      root.appendChild(questionScreen());
    }

    function startScreen() {
      var list = pool();
      var done = Store.completedIds(state.exam, state.trainer);
      var completedInPool = list.filter(function (item) { return done.indexOf(item.id) !== -1; }).length;
      var wrap = el('div', { class: 'quiz-start' });
      var card = EE.card([
        el('span', { class: 'eyebrow', text: 'АВТОРСКАЯ ПРАКТИКА · ' + EE.examLabel(state.exam) }),
        el('h2', { text: speed ? '60 секунд на точность' : 'Короткая практика' }),
        el('p', { class: 'muted', text: speed
          ? 'Ответь на столько заданий, сколько успеешь за минуту. Результат сохраняется в этом браузере.'
          : 'До 10 неповторяющихся заданий с разбором каждого ответа. Задания авторские, не банк ФИПИ.' }),
        el('div', { class: 'quiz-settings' }, [
          el('div', { class: 'settings-line' }, [
            el('span', { class: 'settings-label', text: 'Сложность' }),
            el('div', { class: 'pill-row' }, [{ value: 'all', label: 'Все' }, { value: '1', label: 'Уровень 1' }, { value: '2', label: 'Уровень 2' }, { value: '3', label: 'Уровень 3' }].map(function (option) {
              var btn = el('button', { type: 'button', class: 'pill' + (String(state.difficulty) === option.value ? ' is-active' : ''), text: option.label });
              btn.addEventListener('click', function () { state.difficulty = option.value === 'all' ? 'all' : Number(option.value); render(); });
              return btn;
            }))
          ]),
          el('div', { class: 'settings-line' }, [
            el('span', { class: 'settings-label', text: 'Порядок' }),
            el('div', { class: 'pill-row' }, [{ value: 'shuffle', label: 'Перемешать' }, { value: 'sequential', label: 'По порядку' }].map(function (option) {
              var btn = el('button', { type: 'button', class: 'pill' + (state.order === option.value ? ' is-active' : ''), text: option.label });
              btn.addEventListener('click', function () { state.order = option.value; render(); });
              return btn;
            }))
          ])
        ]),
        el('div', { class: 'quiz-foot' }, [
          el('span', { class: 'hint', text: list.length + ' всего · ' + completedInPool + ' выполнено · ' + Math.max(0, list.length - completedInPool) + ' осталось' }),
          el('button', { type: 'button', class: 'btn btn-primary', text: 'Начать', disabled: list.length ? null : 'disabled' })
        ])
      ]);
      card.querySelector('.btn-primary').addEventListener('click', start);
      wrap.appendChild(card);
      wrap.appendChild(EE.card([
        el('span', { class: 'eyebrow', text: 'КАК ЭТО РАБОТАЕТ' }),
        el('ol', { class: 'how-list' }, [
          el('li', { text: 'Решай самостоятельно — правильный ответ не показывается до проверки.' }),
          el('li', { text: 'После проверки читай объяснение и правило.' }),
          el('li', { text: 'Неверные ответы попадают в «Мои ошибки» на этом устройстве.' })
        ])
      ], 'card-side'));
      return wrap;
    }

    function start() {
      var list = pool();
      var count = Math.min(speed ? 12 : 10, list.length);
      state.session = state.order === 'shuffle' ? EE.shuffle(list).slice(0, count) : list.slice(0, count);
      state.index = 0; state.answers = {}; state.checked = false; state.finished = false;
      state.timeLeft = 60; state.startedAt = Date.now();
      if (state.timer) window.clearInterval(state.timer);
      if (speed) {
        state.timer = window.setInterval(function () {
          state.timeLeft -= 1;
          var chip = root.querySelector('.timer-chip');
          if (chip) chip.textContent = state.timeLeft + ' c';
          if (state.timeLeft <= 0) { window.clearInterval(state.timer); finish(); }
        }, 1000);
      }
      render();
    }

    function currentItem() { return state.session[state.index]; }

    function questionScreen() {
      var item = currentItem();
      var wrap = el('div', { class: 'quiz-player' });
      var head = el('div', { class: 'quiz-head' }, [
        el('span', { class: 'eyebrow', text: 'ВОПРОС ' + (state.index + 1) + ' ИЗ ' + state.session.length }),
        el('div', { class: 'quiz-meta' }, [
          EE.badge(item.topic),
          speed ? el('span', { class: 'timer-chip', text: state.timeLeft + ' c' }) : null
        ].filter(Boolean))
      ]);
      var progress = el('div', { class: 'quiz-progress' });
      state.session.forEach(function (_, index) {
        progress.appendChild(el('i', { class: index < state.index ? 'done' : index === state.index ? 'current' : '' }));
      });

      var body = el('div', { class: 'quiz-body' });
      body.appendChild(el('div', { class: 'question-label', text: trainerId === 'reading' ? 'ПРОЧИТАЙ И ОТВЕТЬ' : trainerId === 'listening' ? 'ПРОСЛУШАЙ И ОТВЕТЬ' : trainerId === 'wordformation' ? 'ВЫБЕРИ НУЖНУЮ ФОРМУ' : 'ВЫБЕРИ ОТВЕТ' }));
      if (item.section === 'reading' && item.passage) {
        var passage = el('div', { class: 'passage' });
        passage.appendChild(el('div', { class: 'passage-head' }, [el('span', { text: 'ТЕКСТ ДЛЯ ЧТЕНИЯ' }), EE.speechControl(item.passage, { compact: true, label: 'Прослушать текст' })]));
        passage.appendChild(el('p', { text: item.passage }));
        body.appendChild(passage);
      }
      if (item.section === 'listening') body.appendChild(listeningPlayer(item, state.checked));
      body.appendChild(el('h2', { class: 'question', text: item.prompt }));

      var options = el('div', { class: 'options' });
      item.options.forEach(function (option, index) {
        var chosen = state.answers[item.id] === option;
        var cls = 'option';
        if (chosen) cls += ' is-chosen';
        if (state.checked) {
          if (option === item.answer) cls += ' is-right';
          else if (chosen) cls += ' is-wrong';
        }
        var btn = el('button', { type: 'button', class: cls, disabled: state.checked ? 'disabled' : null }, [
          el('span', { class: 'option-key', text: String.fromCharCode(65 + index) }),
          el('span', { text: option })
        ]);
        btn.addEventListener('click', function () {
          if (state.checked) return;
          state.answers[item.id] = option;
          render();
        });
        options.appendChild(btn);
      });
      body.appendChild(options);

      if (state.checked) {
        var correct = state.answers[item.id] === item.answer;
        var panel = el('div', { class: 'explanation ' + (correct ? 'is-right' : 'is-wrong') }, [
          el('b', { text: correct ? 'Верно' : 'Неверно. Правильный ответ: ' + item.answer }),
          el('p', { text: item.explanation })
        ]);
        if (item.section === 'listening' && item.passage) {
          var details = el('details', { class: 'transcript' }, [el('summary', { text: 'Показать текст записи' }), el('p', { text: item.passage })]);
          panel.appendChild(details);
        }
        body.appendChild(panel);
      }

      var footer = el('div', { class: 'quiz-footer' }, [
        el('span', { class: 'hint', text: state.checked ? 'Ответ проверен — разбор сохранён в истории этого браузера.' : 'Выбери один ответ, затем проверь себя.' })
      ]);
      if (state.checked) {
        var next = el('button', { type: 'button', class: 'btn btn-primary', text: state.index === state.session.length - 1 ? 'Завершить раунд' : 'Следующий вопрос' });
        next.addEventListener('click', function () {
          if (state.index === state.session.length - 1) finish();
          else { state.index += 1; state.checked = false; render(); }
        });
        footer.appendChild(next);
      } else {
        var checkBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Проверить ответ', disabled: state.answers[item.id] ? null : 'disabled' });
        checkBtn.addEventListener('click', function () { check(); });
        footer.appendChild(checkBtn);
      }

      wrap.appendChild(head); wrap.appendChild(progress); wrap.appendChild(body); wrap.appendChild(footer);
      return wrap;
    }

    function check() {
      var item = currentItem();
      var given = state.answers[item.id];
      if (!given) return;
      var correct = given === item.answer;
      Store.markCompleted(state.exam, state.trainer, item.id);
      if (correct) {
        Store.state.correctCount = (Store.state.correctCount || 0) + 1;
        Store.save();
      } else {
        Store.addWrong({
          exam: state.exam, trainer: state.trainer, id: item.id, prompt: item.prompt,
          answer: item.answer, given: given, explanation: item.explanation, at: new Date().toISOString()
        });
      }
      state.checked = true;
      render();
    }

    function finish() {
      if (state.timer) window.clearInterval(state.timer);
      var correct = state.session.filter(function (item) { return state.answers[item.id] === item.answer; }).length;
      var minutes = speed ? 1 : Math.max(1, Math.round((Date.now() - state.startedAt) / 60000));
      state.finished = true;
      Store.addAttempt(state.exam, state.trainer, correct, state.session.length, minutes);
      render();
    }

    function resultScreen() {
      var correct = state.session.filter(function (item) { return state.answers[item.id] === item.answer; }).length;
      var wrap = el('div', { class: 'quiz-result' });
      var hero = EE.card([
        el('div', { class: 'score-ring' }, [el('b', { text: EE.pct(correct, state.session.length) + '%' })]),
        el('div', {}, [
          el('span', { class: 'eyebrow', text: 'РАУНД ЗАВЕРШЁН' }),
          el('h2', { text: correct + ' из ' + state.session.length + ' верно' }),
          el('p', { class: 'muted', text: 'Результат сохранён в этом браузере отдельно для ' + EE.examLabel(state.exam) + '.' })
        ])
      ], 'result-hero');
      var again = el('button', { type: 'button', class: 'btn btn-primary', text: 'Ещё раунд' });
      again.addEventListener('click', function () { state.session = null; state.finished = false; render(); });
      hero.appendChild(el('div', { class: 'result-actions' }, [again, el('a', { class: 'btn btn-secondary', href: './errors.html', text: 'Мои ошибки' })]));
      wrap.appendChild(hero);

      var review = EE.card([el('h2', { text: 'Разбор заданий' })]);
      var list = el('div', { class: 'review-list' });
      state.session.forEach(function (item, index) {
        var given = state.answers[item.id];
        var ok = given === item.answer;
        list.appendChild(el('div', { class: 'review-row ' + (ok ? 'is-right' : 'is-wrong') }, [
          el('span', { class: 'review-num', text: String(index + 1).padStart(2, '0') }),
          el('div', { class: 'review-body' }, [
            el('b', { text: item.topic }),
            el('p', { text: item.prompt }),
            el('div', { class: 'review-answers' }, [
              el('span', { class: ok ? 'is-right' : 'is-wrong', text: 'Твой ответ: ' + (given || 'не дан') }),
              ok ? null : el('span', { class: 'is-right', text: 'Верно: ' + item.answer })
            ].filter(Boolean)),
            el('small', { text: item.explanation })
          ]),
          el('span', { class: 'review-mark ' + (ok ? 'ok' : 'bad'), text: ok ? '✓' : '✕' })
        ]));
      });
      review.appendChild(list);
      wrap.appendChild(review);
      return wrap;
    }

    render();
  }

  /* ------------------------------------------------------------------ */
  /* письмо                                                             */
  /* ------------------------------------------------------------------ */
  function checkStructure(task, value) {
    var count = EE.words(value);
    var lower = value.toLowerCase();
    var isEmail = task.taskType === 'personal-email';
    var min = task.minimumWords || (isEmail ? 90 : 180);
    var max = task.maximumWords || (isEmail ? 154 : 275);
    var checks = [];
    if (isEmail) {
      checks.push({ label: 'Есть обращение', ok: /^(hi|hello|dear)\b/i.test(value.trim()) });
      checks.push({ label: 'Задано 2–3 встречных вопроса', ok: (value.match(/\?/g) || []).length >= 2 });
      checks.push({ label: 'Есть завершающая фраза', ok: /(best wishes|yours|take care|see you|all the best)/.test(lower) });
      checks.push({ label: 'Есть подпись', ok: /\n\s*[A-Z][a-z]+/.test(value) });
    } else {
      checks.push({ label: 'Есть вступление о теме', ok: /(the (table|chart|diagram|figures)|the data)/.test(lower) });
      checks.push({ label: 'Приведены цифры или сравнение', ok: /\d/.test(value) && /(whereas|while|compared|more|less|higher|lower)/.test(lower) });
      checks.push({ label: 'Есть вывод/общая картина', ok: /(overall|in conclusion|to sum up)/.test(lower) });
      checks.push({ label: 'Есть мнение и проблема', ok: /(i (think|believe)|in my opinion)/.test(lower) });
    }
    checks.push({ label: 'Объём в диапазоне ' + min + '–' + max + ' слов', ok: count >= min && count <= max });
    return { count: count, min: min, max: max, checks: checks };
  }

  function writingTrainer(root, exam) {
    var tasks = (DATA.tasks.writing[exam] || []);
    var state = { exam: exam, taskId: (tasks[0] || {}).id, saved: false, done: false };

    function render() {
      clear(root);
      if (!tasks.length) { root.appendChild(EE.emptyState('Заданий нет', 'Для этого экзамена письменные задания ещё не добавлены.')); return; }
      var task = tasks.filter(function (item) { return item.id === state.taskId; })[0] || tasks[0];
      var draftKey = state.exam + ':' + task.id;
      var stored = Store.state.drafts[draftKey] || '';

      var picker = el('div', { class: 'task-picker' });
      var prev = el('button', { type: 'button', class: 'icon-btn', text: '←', 'aria-label': 'Предыдущее задание' });
      var next = el('button', { type: 'button', class: 'icon-btn', text: '→', 'aria-label': 'Следующее задание' });
      var select = el('select', { class: 'task-select', 'aria-label': 'Выбор задания письма' },
        tasks.map(function (item, index) {
          return el('option', { value: item.id, text: (index + 1) + ' из ' + tasks.length + ' · ' + item.title });
        }));
      select.value = task.id;
      select.addEventListener('change', function () { state.taskId = select.value; render(); });
      prev.addEventListener('click', function () {
        var at = tasks.indexOf(task);
        state.taskId = tasks[(at - 1 + tasks.length) % tasks.length].id; render();
      });
      next.addEventListener('click', function () {
        var at = tasks.indexOf(task);
        state.taskId = tasks[(at + 1) % tasks.length].id; render();
      });
      picker.appendChild(prev);
      picker.appendChild(el('label', { class: 'task-picker-label' }, [el('span', { text: 'Задание' }), select]));
      picker.appendChild(next);

      var area = el('textarea', { class: 'writing-area', rows: '12', placeholder: 'Напиши ответ на английском…', 'aria-label': 'Ответ на письменное задание' });
      area.value = stored;
      var counter = el('span', { class: 'word-count' });
      var saveState = el('span', { class: 'hint', text: stored ? 'Черновик сохранён' : 'Черновик сохранится автоматически' });
      var checklist = el('div', { class: 'checklist' });

      function update() {
        var result = checkStructure(task, area.value);
        counter.textContent = result.count + ' слов';
        clear(checklist);
        result.checks.forEach(function (item) {
          checklist.appendChild(el('span', { class: 'check ' + (item.ok ? 'is-ok' : '') }, [el('i', { text: item.ok ? '✓' : '•' }), text(item.label)]));
        });
        try {
          if (area.value.trim()) Store.state.drafts[draftKey] = area.value;
          else delete Store.state.drafts[draftKey];
          Store.save();
          saveState.textContent = 'Черновик сохранён в этом браузере';
        } catch (error) { saveState.textContent = 'Не удалось сохранить черновик'; }
        const doneKey = state.exam + ':writing:' + task.id;
        markBtn.textContent = Store.state.done[doneKey] ? 'Работа отмечена выполненной' : 'Отметить работу выполненной';
        markBtn.disabled = Boolean(Store.state.done[doneKey]) || !area.value.trim();
      }

      var markBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Отметить работу выполненной' });
      markBtn.addEventListener('click', function () {
        Store.state.done[state.exam + ':writing:' + task.id] = true;
        Store.addMinutes(10);
        Store.markCompleted(state.exam, 'writing', task.id);
        Store.save();
        update();
      });
      var timerId = null;
      area.addEventListener('input', function () {
        if (timerId) window.clearTimeout(timerId);
        timerId = window.setTimeout(update, 250);
      });

      var card = EE.card([
        el('div', { class: 'card-head' }, [
          el('div', {}, [el('span', { class: 'eyebrow', text: 'АВТОРСКАЯ ПРАКТИКА · ' + EE.examLabel(state.exam) }), el('h2', { text: 'Письменное задание' })]),
          EE.badge(task.title, EE.examTone(state.exam))
        ]),
        picker,
        el('div', { class: 'prompt-box', text: task.prompt }),
        el('ul', { class: 'criteria' }, (task.criteria || []).map(function (item) { return el('li', { text: item }); })),
        el('div', { class: 'editor' }, [
          el('div', { class: 'editor-head' }, [el('b', { text: 'Твой ответ' }), el('div', { class: 'editor-meta' }, [saveState, counter])]),
          area
        ]),
        el('div', { class: 'editor-foot', text: '' }),
        markBtn,
        el('div', { class: 'checklist-box' }, [el('b', { text: 'Самопроверка структуры' }), checklist]),
        el('p', { class: 'hint', text: 'Проверяются объём и видимые структурные признаки. Грамматику и лексику проверь сам(а) или с учителем: на платформе нет ИИ-проверки, текст никуда не отправляется.' })
      ]);
      root.appendChild(card);
      update();
    }
    render();
  }

  /* ------------------------------------------------------------------ */
  /* говорение                                                          */
  /* ------------------------------------------------------------------ */
  function speakingTrainer(root, exam) {
    var tasks = (DATA.tasks.speaking[exam] || []);
    var state = { exam: exam, taskId: (tasks[0] || {}).id, seconds: 0, timer: null, recorder: null, chunks: [], url: '' };

    function render() {
      clear(root);
      if (!tasks.length) { root.appendChild(EE.emptyState('Заданий нет', 'Для этого экзамена устные задания ещё не добавлены.')); return; }
      var task = tasks.filter(function (item) { return item.id === state.taskId; })[0] || tasks[0];
      var index = tasks.indexOf(task);

      var select = el('select', { class: 'task-select', 'aria-label': 'Выбор устного задания' },
        tasks.map(function (item, i) { return el('option', { value: item.id, text: (i + 1) + ' из ' + tasks.length + ' · ' + item.title }); }));
      select.value = task.id;
      select.addEventListener('change', function () { state.taskId = select.value; stopTimer(); render(); });

      var timerValue = el('b', { class: 'timer-value', text: '00:00' });
      var startBtn = el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: 'Старт' });
      var pauseBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Пауза' });
      var resetBtn = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Сбросить' });
      function paintTimer() {
        timerValue.textContent = String(Math.floor(state.seconds / 60)).padStart(2, '0') + ':' + String(state.seconds % 60).padStart(2, '0');
      }
      startBtn.addEventListener('click', function () {
        if (state.timer) return;
        state.timer = window.setInterval(function () { state.seconds += 1; paintTimer(); }, 1000);
      });
      pauseBtn.addEventListener('click', stopTimer);
      resetBtn.addEventListener('click', function () { stopTimer(); state.seconds = 0; paintTimer(); });

      var recordBox = el('div', { class: 'record-box' });
      var recordBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Начать запись' });
      var statusLine = el('span', { class: 'hint', text: 'Микрофон браузер запросит после нажатия кнопки.' });
      var playback = el('div', { class: 'record-playback' });

      recordBtn.addEventListener('click', function () {
        if (state.recorder && state.recorder.state === 'recording') { state.recorder.stop(); return; }
        if (!navigator.mediaDevices || !window.MediaRecorder) {
          statusLine.textContent = 'Этот браузер не поддерживает запись с микрофона. Можно тренироваться вслух с таймером.';
          return;
        }
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
          state.chunks = [];
          var recorder = new window.MediaRecorder(stream);
          state.recorder = recorder;
          recorder.addEventListener('dataavailable', function (event) { if (event.data && event.data.size) state.chunks.push(event.data); });
          recorder.addEventListener('stop', function () {
            stream.getTracks().forEach(function (track) { track.stop(); });
            var blob = new Blob(state.chunks, { type: state.chunks[0] ? state.chunks[0].type : 'audio/webm' });
            if (state.url) URL.revokeObjectURL(state.url);
            state.url = URL.createObjectURL(blob);
            clear(playback);
            playback.appendChild(el('audio', { controls: 'controls', src: state.url, 'aria-label': 'Прослушать запись' }));
            var del = el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Удалить' });
            del.addEventListener('click', function () {
              clear(playback);
              if (state.url) URL.revokeObjectURL(state.url);
              state.url = '';
            });
            playback.appendChild(del);
            recordBtn.textContent = 'Начать запись';
            statusLine.textContent = 'Запись доступна в этой вкладке. В статической сборке она не сохраняется между перезагрузками.';
          });
          recorder.start();
          recordBtn.textContent = 'Остановить запись';
          statusLine.textContent = 'Идёт запись. Говори по-английски, не спеша.';
        }).catch(function () {
          statusLine.textContent = 'Доступ к микрофону не разрешён. Разреши его в настройках браузера или тренируйся вслух с таймером.';
        });
      });

      var doneBtn = el('button', { type: 'button', class: 'btn btn-secondary', text: 'Отметить выполненным' });
      doneBtn.addEventListener('click', function () {
        Store.markCompleted(state.exam, 'speaking', task.id);
        Store.addMinutes(3);
        Store.save();
        doneBtn.textContent = 'Отмечено в прогрессе';
        doneBtn.disabled = true;
      });

      root.appendChild(EE.card([
        el('div', { class: 'card-head' }, [
          el('div', {}, [el('span', { class: 'eyebrow', text: 'УСТНАЯ ПРАКТИКА · ' + EE.examLabel(state.exam) }), el('h2', { text: task.title })]),
          EE.badge((index + 1) + ' / ' + tasks.length, EE.examTone(state.exam))
        ]),
        select,
        el('div', { class: 'prompt-box', text: task.prompt }),
        (task.media && task.media.length) ? el('div', { class: 'speaking-media' }, task.media.map(function (media) {
          return el('figure', {}, [el('img', { src: './img/' + media.src.split('/').pop(), alt: media.alt, loading: 'lazy' }), el('figcaption', { text: media.caption })]);
        })) : null,
        el('div', { class: 'speak-sample' }, [EE.speechControl(task.prompt, { compact: true, label: 'Прослушать образец' }), el('span', { class: 'hint', text: 'Голос браузера — для тренировки чтения вслух.' })]),
        (task.criteria && task.criteria.length) ? el('ul', { class: 'criteria' }, task.criteria.map(function (item) { return el('li', { text: item }); })) : null,
        el('div', { class: 'timer-box' }, [
          el('div', {}, [el('b', { text: 'Таймер самостоятельной практики' }), el('span', { class: 'hint', text: 'Свободный секундомер, не официальный норматив ФИПИ.' })]),
          timerValue,
          el('div', { class: 'timer-actions' }, [startBtn, pauseBtn, resetBtn])
        ]),
        el('div', { class: 'record-card' }, [el('div', { class: 'record-head' }, [el('b', { text: 'Запись ответа' }), statusLine]), recordBtn, playback]),
        doneBtn
      ].filter(Boolean)));
    }

    function stopTimer() {
      if (state.timer) { window.clearInterval(state.timer); state.timer = null; }
    }
    render();
  }

  /* ------------------------------------------------------------------ */
  /* словарь                                                            */
  /* ------------------------------------------------------------------ */
  function dictionaryTrainer(root, exam) {
    var state = { exam: exam, query: '', formOpen: false };
    function seed() {
      var list = Store.state.dictionary[state.exam] || (Store.state.dictionary[state.exam] = []);
      var seeds = (DATA.dictionarySeed[state.exam] || []);
      if (!Store.state.dictionary[state.exam + ':seeded'] && seeds.length) {
        seeds.forEach(function (word) {
          if (!list.some(function (item) { return item.word === word.word; })) {
            list.push({ id: 'seed-' + word.word, word: word.word, transcription: word.transcription, translation: word.translation, example: word.example, topic: word.topic });
          }
        });
        Store.state.dictionary[state.exam + ':seeded'] = true;
        Store.save();
      }
    }
    function render() {
      seed();
      clear(root);
      var list = (Store.state.dictionary[state.exam] || []).filter(function (item) {
        var q = state.query.trim().toLowerCase();
        if (!q) return true;
        return (item.word + ' ' + item.translation).toLowerCase().indexOf(q) !== -1;
      });
      var wrapper = el('div', { class: 'dictionary' });
      var head = el('div', { class: 'dictionary-head' }, [
        el('div', { class: 'dict-stats' }, [
          el('div', {}, [el('b', { text: String((Store.state.dictionary[state.exam] || []).length) }), el('span', { text: 'слов в подборке ' + EE.examLabel(state.exam) })]),
          el('div', {}, [el('b', { text: String((Store.state.dictionary[state.exam] || []).length) }), el('span', { text: 'всего в этом браузере' })])
        ]),
        el('div', { class: 'dict-actions' }, [
          el('input', { class: 'search', type: 'search', placeholder: 'Поиск по слову или переводу', 'aria-label': 'Поиск по словарю', value: state.query, oninput: function (event) { state.query = event.target.value; render(); } }),
          el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: 'Добавить слово', onclick: function () { state.formOpen = true; render(); } })
        ])
      ]);
      wrapper.appendChild(head);

      if (state.formOpen) {
        var word = el('input', { placeholder: 'Слово или выражение', 'aria-label': 'Слово или выражение' });
        var transcription = el('input', { placeholder: '/транскрипция/', 'aria-label': 'Транскрипция' });
        var translation = el('input', { placeholder: 'Перевод', 'aria-label': 'Перевод' });
        var example = el('input', { placeholder: 'Пример на английском', 'aria-label': 'Пример' });
        var form = el('div', { class: 'dict-form' }, [
          el('div', { class: 'form-grid' }, [word, transcription, translation, example]),
          el('div', { class: 'form-actions' }, [
            el('button', { type: 'button', class: 'btn btn-primary btn-sm', text: 'Сохранить слово', onclick: function () {
              if (!word.value.trim() || !translation.value.trim()) return;
              var bag = Store.state.dictionary[state.exam] || (Store.state.dictionary[state.exam] = []);
              bag.unshift({ id: 'w-' + Date.now(), word: word.value.trim(), transcription: transcription.value.trim(), translation: translation.value.trim(), example: example.value.trim(), topic: 'Своё слово' });
              Store.save();
              state.formOpen = false;
              render();
            } }),
            el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Отмена', onclick: function () { state.formOpen = false; render(); } })
          ])
        ]);
        wrapper.appendChild(form);
      }

      if (!list.length) {
        wrapper.appendChild(EE.emptyState('Пока нет слов', 'Добавь слово вручную или измени поиск.'));
      } else {
        var items = el('div', { class: 'dict-list' });
        list.forEach(function (item) {
          var card = el('article', { class: 'dict-item' }, [
            el('div', { class: 'dict-item-head' }, [
              el('div', {}, [el('b', { text: item.word }), item.transcription ? el('span', { class: 'transcription', text: item.transcription }) : null].filter(Boolean)),
              el('div', { class: 'dict-item-actions' }, [
                EE.speechControl(item.word + '. ' + (item.example || ''), { compact: true, label: 'Озвучить' }),
                el('button', { type: 'button', class: 'icon-btn', title: 'Удалить', 'aria-label': 'Удалить слово', text: '✕', onclick: function () {
                  var bag = Store.state.dictionary[state.exam] || [];
                  Store.state.dictionary[state.exam] = bag.filter(function (entry) { return entry.id !== item.id; });
                  Store.save();
                  render();
                } })
              ])
            ]),
            el('p', { class: 'translation', text: item.translation }),
            item.example ? el('small', { text: item.example }) : null
          ].filter(Boolean));
          items.appendChild(card);
        });
        wrapper.appendChild(items);
      }
      root.appendChild(wrapper);
    }
    render();
  }

  /* ------------------------------------------------------------------ */
  /* огонёк учёбы                                                       */
  /* ------------------------------------------------------------------ */
  function streakTrainer(root, exam) {
    function render() {
      clear(root);
      var state = Store.state;
      var days = Object.keys(state.activity).sort().slice(-14);
      var streak = Store.streak();
      var total = Object.keys(state.activity).reduce(function (sum, key) { return sum + state.activity[key]; }, 0);
      var card = EE.card([
        el('span', { class: 'eyebrow', text: 'РЕГУЛЯРНОСТЬ · ' + EE.examLabel(exam) }),
        el('h2', { text: 'Огонёк учёбы' }),
        el('p', { class: 'muted', text: 'Считается по фактическим дням практики в этом браузере. Ничего не отправляется на сервер.' }),
        el('div', { class: 'streak-figures' }, [
          el('div', {}, [el('b', { text: String(streak) }), el('span', { text: 'дней подряд' })]),
          el('div', {}, [el('b', { text: String(total) }), el('span', { text: 'минут практики' })]),
          el('div', {}, [el('b', { text: String(Object.keys(state.activity).length) }), el('span', { text: 'дней с занятиями' })]),
          el('div', {}, [el('b', { text: String(state.attempts.length) }), el('span', { text: 'завершённых раундов' })])
        ]),
        el('div', { class: 'calendar' }, (days.length ? days : [todayKey()]).map(function (day) {
          return el('div', { class: 'calendar-day' + (state.activity[day] ? ' is-active' : '') }, [el('span', { text: day.slice(5) }), el('b', { text: String(state.activity[day] || 0) })]);
        })),
        el('a', { class: 'btn btn-secondary', href: './dashboard.html', text: 'Открыть прогресс' })
      ]);
      root.appendChild(card);
      if (!days.length) root.appendChild(el('p', { class: 'hint', text: 'Пока нет занятий: реши один раунд в любом тренажёре, и день появится здесь.' }));
    }
    render();
  }

  function todayKey() { return new Date().toISOString().slice(0, 10); }

  /* ------------------------------------------------------------------ */
  /* тренировочная сессия и диагностика                                  */
  /* ------------------------------------------------------------------ */
  function sessionEngine(root, options) {
    var exam = options.exam, size = options.size, minutes = options.minutes, label = options.label, trainer = options.trainer;
    var state = { session: null, index: 0, answers: {}, finished: false, left: minutes * 60, timer: null, result: null };

    function bank() {
      var all = (DATA.exercises[exam] || []);
      return all.filter(function (item) { return item.options && item.options.length >= 2; });
    }

    function render() {
      clear(root);
      if (!state.session) { root.appendChild(startScreen()); return; }
      if (state.finished) { root.appendChild(resultScreen()); return; }
      root.appendChild(sessionScreen());
    }

    function startScreen() {
      var total = bank().length;
      var wrap = el('div', { class: 'start-grid' });
      var startBtn = el('button', { type: 'button', class: 'btn btn-primary', text: options.startLabel || 'Начать тренировку', disabled: total < size ? 'disabled' : null });
      startBtn.addEventListener('click', start);
      wrap.appendChild(EE.card([
        el('span', { class: 'eyebrow', text: EE.examLabel(exam) + ' · УЧЕБНЫЙ РЕЖИМ' }),
        el('h2', { text: label }),
        el('p', { class: 'muted', text: size + ' заданий · ' + minutes + ' минут. Задания авторские: это не КИМ ФИПИ и не официальный балл.' }),
        el('div', { class: 'facts' }, [
          el('span', { text: '⏱ Таймер и автосохранение ответов' }),
          el('span', { text: '✓ Разбор после завершения' }),
          el('span', { text: '💾 Результат остаётся в браузере' })
        ]),
        startBtn,
        el('p', { class: 'hint', text: total ? 'Доступно заданий в банке: ' + total + '.' : 'В банке нет заданий с вариантами ответа.' })
      ]));
      var config = DATA.exams[exam];
      if (config) {
        wrap.appendChild(EE.card([
          el('span', { class: 'eyebrow', text: 'ОФИЦИАЛЬНАЯ СТРУКТУРА ' + (config.year || 2027) }),
          el('h3', { text: config.taskCount + ' заданий · ' + config.maxPrimaryScore + ' первичных баллов' }),
          el('p', { class: 'muted', text: config.writtenMinutes + ' мин письменная часть · ' + config.oralMinutes + ' мин устная часть' }),
          el('div', { class: 'spec-list' }, (config.sections || []).map(function (section) {
            return el('div', {}, [el('span', { text: section.title }), el('b', { text: '№ ' + section.taskRange })]);
          })),
          el('a', { class: 'link', href: config.officialUrl, target: '_blank', rel: 'noreferrer', text: 'Официальные материалы ФИПИ' })
        ], 'card-side'));
      }
      return wrap;
    }

    function start() {
      var picked = EE.shuffle(bank()).slice(0, size);
      state.session = picked; state.index = 0; state.answers = {}; state.finished = false; state.left = minutes * 60;
      if (state.timer) window.clearInterval(state.timer);
      state.timer = window.setInterval(function () {
        state.left -= 1;
        var chip = root.querySelector('.session-timer');
        if (chip) chip.textContent = Math.floor(state.left / 60) + ':' + String(state.left % 60).padStart(2, '0');
        if (state.left <= 0) finish();
      }, 1000);
      render();
    }

    function sessionScreen() {
      var item = state.session[state.index];
      var wrap = el('div', { class: 'session' });
      wrap.appendChild(el('div', { class: 'session-top' }, [
        el('span', { class: 'hint', text: 'Задание ' + (state.index + 1) + ' из ' + state.session.length }),
        el('span', { class: 'session-timer', text: Math.floor(state.left / 60) + ':' + String(state.left % 60).padStart(2, '0') }),
        el('span', { class: 'hint', text: Object.keys(state.answers).length + ' ответов' })
      ]));
      var card = EE.card([]);
      card.appendChild(el('div', { class: 'session-label' }, [EE.badge(sectionLabel(item.section), EE.examTone(exam)), el('span', { class: 'hint', text: 'Тренировочное задание' })]));
      if (item.section === 'reading' && item.passage) {
        var passage = el('div', { class: 'passage' });
        passage.appendChild(el('div', { class: 'passage-head' }, [el('span', { text: 'ТЕКСТ' }), EE.speechControl(item.passage, { compact: true, label: 'Прослушать текст' })]));
        passage.appendChild(el('p', { text: item.passage }));
        card.appendChild(passage);
      }
      if (item.section === 'listening') card.appendChild(listeningPlayer(item, false));
      card.appendChild(el('h2', { class: 'question', text: item.prompt }));
      var options = el('div', { class: 'options' });
      item.options.forEach(function (option, i) {
        var btn = el('button', { type: 'button', class: 'option' + (state.answers[item.id] === option ? ' is-chosen' : '') }, [
          el('span', { class: 'option-key', text: String.fromCharCode(65 + i) }),
          el('span', { text: option })
        ]);
        btn.addEventListener('click', function () { state.answers[item.id] = option; render(); });
        options.appendChild(btn);
      });
      card.appendChild(options);
      var nav = el('div', { class: 'session-nav' });
      state.session.forEach(function (question, i) {
        nav.appendChild(el('button', {
          type: 'button',
          class: 'nav-dot' + (i === state.index ? ' is-current' : '') + (state.answers[question.id] ? ' is-answered' : ''),
          text: String(i + 1),
          'aria-label': 'Задание ' + (i + 1),
          onclick: function () { state.index = i; render(); }
        }));
      });
      card.appendChild(nav);
      var footer = el('div', { class: 'session-footer' }, [
        el('span', { class: 'hint', text: 'Ответы сохраняются только в этой вкладке до завершения раунда.' })
      ]);
      var actions = el('div', { class: 'session-actions' });
      if (state.index > 0) actions.appendChild(el('button', { type: 'button', class: 'btn btn-secondary', text: 'Назад', onclick: function () { state.index -= 1; render(); } }));
      if (state.index < state.session.length - 1) {
        actions.appendChild(el('button', { type: 'button', class: 'btn btn-primary', text: 'Следующее', onclick: function () { state.index += 1; render(); } }));
      } else {
        actions.appendChild(el('button', { type: 'button', class: 'btn btn-primary', text: 'Завершить', onclick: function () { if (window.confirm('Завершить раунд?')) finish(); } }));
      }
      footer.appendChild(actions);
      card.appendChild(footer);
      wrap.appendChild(card);
      return wrap;
    }

    function finish() {
      if (state.timer) window.clearInterval(state.timer);
      var correct = state.session.filter(function (item) { return state.answers[item.id] === item.answer; }).length;
      state.result = { correct: correct, total: state.session.length, minutes: Math.max(1, Math.round((minutes * 60 - state.left) / 60)) };
      state.finished = true;
      Store.addAttempt(exam, trainer, correct, state.session.length, state.result.minutes);
      state.session.forEach(function (item) {
        if (state.answers[item.id] === item.answer) Store.markCompleted(exam, trainer, item.id);
        else if (state.answers[item.id]) {
          Store.addWrong({ exam: exam, trainer: trainer, id: item.id, prompt: item.prompt, answer: item.answer, given: state.answers[item.id], explanation: item.explanation, at: new Date().toISOString() });
        }
      });
      render();
    }

    function resultScreen() {
      var result = state.result;
      var wrap = el('div', { class: 'quiz-result' });
      wrap.appendChild(EE.card([
        el('div', { class: 'score-ring' }, [el('b', { text: EE.pct(result.correct, result.total) + '%' })]),
        el('div', {}, [
          el('span', { class: 'eyebrow', text: 'РАУНД ЗАВЕРШЁН' }),
          el('h2', { text: result.correct + ' из ' + result.total + ' верно' }),
          el('p', { class: 'muted', text: 'Результат учебный: это не первичный балл ФИПИ. Сохранён в этом браузере.' })
        ])
      ], 'result-hero'));
      var review = EE.card([el('h2', { text: 'Разбор заданий' })]);
      state.session.forEach(function (item, i) {
        var given = state.answers[item.id];
        var ok = given === item.answer;
        review.appendChild(el('div', { class: 'review-row ' + (ok ? 'is-right' : 'is-wrong') }, [
          el('span', { class: 'review-num', text: String(i + 1).padStart(2, '0') }),
          el('div', { class: 'review-body' }, [
            el('b', { text: item.topic }),
            el('p', { text: item.prompt }),
            el('div', { class: 'review-answers' }, [
              el('span', { class: ok ? 'is-right' : 'is-wrong', text: 'Твой ответ: ' + (given || 'не дан') }),
              ok ? null : el('span', { class: 'is-right', text: 'Верно: ' + item.answer })
            ].filter(Boolean)),
            el('small', { text: item.explanation })
          ]),
          el('span', { class: 'review-mark ' + (ok ? 'ok' : 'bad'), text: ok ? '✓' : '✕' })
        ]));
      });
      wrap.appendChild(review);
      var again = el('button', { type: 'button', class: 'btn btn-primary', text: 'Ещё раунд' });
      again.addEventListener('click', function () { state.session = null; state.finished = false; render(); });
      wrap.appendChild(el('div', { class: 'result-actions' }, [again, el('a', { class: 'btn btn-secondary', href: './dashboard.html', text: 'Мой прогресс' })]));
      return wrap;
    }

    render();
  }

  /* ------------------------------------------------------------------ */
  /* страницы                                                            */
  /* ------------------------------------------------------------------ */
  var pages = {};

  pages.home = function () {
    var host = mount('home-progress');
    if (!host) return;
    var totals = Store.totals();
    clear(host);
    host.appendChild(el('div', { class: 'mini-stats' }, [
      el('div', {}, [el('b', { text: String(totals.rounds) }), el('span', { text: 'раундов завершено' })]),
      el('div', {}, [el('b', { text: totals.accuracy === null ? '—' : totals.accuracy + '%' }), el('span', { text: 'точность ответов' })]),
      el('div', {}, [el('b', { text: String(totals.minutes) }), el('span', { text: 'минут практики' })])
    ]));
  };

  pages.trainers = function () {
    var host = mount('trainer-counters');
    if (!host) return;
    clear(host);
    var exam = Store.state.exam || 'oge';
    var counts = {};
    (DATA.trainers || []).forEach(function (trainer) {
      if (trainer.kind !== 'quiz') return;
      counts[trainer.id] = Store.completedIds(exam, trainer.id).length + '/' + poolFor(exam, trainer.id).length;
    });
    host.appendChild(el('p', { class: 'hint', text: 'Прогресс по ' + EE.examLabel(exam) + ' в этом браузере: ' + Object.keys(counts).map(function (key) { return key + ' ' + counts[key]; }).join(' · ') }));
  };

  pages.trainer = function () {
    var host = mount('trainer-app');
    var trainerId = document.body.getAttribute('data-trainer');
    var exam = Store.state.exam || 'oge';
    if (!host) return;
    var titleHost = mount('trainer-switch');
    function render() {
      if (titleHost) { clear(titleHost); titleHost.appendChild(examSwitch(exam, function (code) { exam = code; render(); })); }
      clear(host);
      if (trainerId === 'writing') return writingTrainer(host, exam);
      if (trainerId === 'speaking') return speakingTrainer(host, exam);
      if (trainerId === 'dictionary') return dictionaryTrainer(host, exam);
      if (trainerId === 'streak') return streakTrainer(host, exam);
      return quizTrainer(host, exam, trainerId);
    }
    render();
  };

  pages.exam = function () {
    var host = mount('exam-app');
    var exam = document.body.getAttribute('data-exam') || 'oge';
    var variant = document.body.getAttribute('data-variant') === 'true';
    if (!host) return;
    sessionEngine(host, {
      exam: exam,
      size: variant ? 25 : 12,
      minutes: variant ? 60 : 25,
      label: variant ? 'Тренировочный вариант' : 'Короткая тренировка',
      startLabel: variant ? 'Начать вариант' : 'Начать тренировку',
      trainer: variant ? 'exam-variant' : 'exam-practice'
    });
  };

  pages.diagnostic = function () {
    var host = mount('diagnostic-app');
    var exam = document.body.getAttribute('data-exam') || 'oge';
    if (!host) return;
    sessionEngine(host, { exam: exam, size: 12, minutes: 20, label: 'Диагностика', startLabel: 'Начать диагностику', trainer: 'diagnostic' });
  };

  pages.dashboard = function () {
    var host = mount('dashboard-app');
    if (!host) return;
    function render() {
      clear(host);
      var totals = Store.totals();
      var state = Store.state;
      host.appendChild(el('div', { class: 'stat-grid' }, [
        el('div', { class: 'stat-card' }, [el('span', { text: 'Раундов завершено' }), el('b', { text: String(totals.rounds) })]),
        el('div', { class: 'stat-card' }, [el('span', { text: 'Точность ответов' }), el('b', { text: totals.accuracy === null ? '—' : totals.accuracy + '%' })]),
        el('div', { class: 'stat-card' }, [el('span', { text: 'Верно / всего заданий' }), el('b', { text: totals.correct + ' / ' + totals.total })]),
        el('div', { class: 'stat-card' }, [el('span', { text: 'Минут практики' }), el('b', { text: String(totals.minutes) })])
      ]));

      ['oge', 'ege'].forEach(function (exam) {
        var trainers = (DATA.trainers || []).filter(function (trainer) { return trainer.kind === 'quiz'; });
        var rows = el('div', { class: 'progress-rows' });
        trainers.forEach(function (trainer) {
          var pool = poolFor(exam, trainer.id).length;
          var done = Store.completedIds(exam, trainer.id).length;
          rows.appendChild(el('div', { class: 'progress-row' }, [
            el('span', { text: trainer.title }),
            EE.progress(pool ? (done / pool) * 100 : 0),
            el('b', { text: done + '/' + pool })
          ]));
        });
        host.appendChild(EE.card([el('span', { class: 'eyebrow', text: EE.examLabel(exam) }), el('h2', { text: 'Прогресс по тренажёрам ' + EE.examLabel(exam) }), rows]));
      });

      var wrong = state.wrong.slice(0, 5);
      host.appendChild(EE.card([
        el('div', { class: 'card-head' }, [el('h2', { text: 'Мои ошибки' }), el('a', { class: 'link', href: './errors.html', text: 'Все ошибки' })]),
        wrong.length ? el('ul', { class: 'error-list' }, wrong.map(function (item) {
          return el('li', {}, [el('b', { text: item.prompt }), el('span', { class: 'hint', text: 'Верно: ' + item.answer + ' · твой ответ: ' + item.given })]);
        })) : el('p', { class: 'hint', text: 'Ошибок пока нет — реши раунд в тренажёре.' })
      ]));

      host.appendChild(EE.card([
        el('div', { class: 'card-head' }, [el('h2', { text: 'Данные на этом устройстве' }), el('span', { class: 'hint', text: 'Без аккаунта и без сервера' })]),
        el('div', { class: 'admin-actions' }, [
          el('button', { type: 'button', class: 'btn btn-secondary btn-sm', text: 'Скачать JSON-копию', onclick: downloadBackup }),
          el('button', { type: 'button', class: 'btn btn-danger btn-sm', text: 'Сбросить прогресс', onclick: resetProgress }),
          el('a', { class: 'btn btn-ghost btn-sm', href: './account.html', text: 'Импорт и настройки' })
        ])
      ]));
    }

    function downloadBackup() {
      var blob = new Blob([JSON.stringify(Store.state, null, 2)], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var link = el('a', { href: url, download: 'english-exam-backup-' + todayKey() + '.json' });
      document.body.appendChild(link); link.click(); link.remove();
      window.setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
    }
    function resetProgress() {
      if (!window.confirm('Удалить весь локальный прогресс, ошибки, словарь и черновики на этом устройстве?')) return;
      Store.reset();
      render();
    }
    Store.on(render);
    render();
  };

  pages.errors = function () {
    var host = mount('errors-app');
    if (!host) return;
    var filter = 'all';
    function render() {
      clear(host);
      var wrong = Store.state.wrong.filter(function (item) { return filter === 'all' || item.exam === filter; });
      host.appendChild(el('div', { class: 'pill-row errors-filter' }, [
        { value: 'all', label: 'Все' }, { value: 'oge', label: 'ОГЭ' }, { value: 'ege', label: 'ЕГЭ' }
      ].map(function (option) {
        var btn = el('button', { type: 'button', class: 'pill' + (filter === option.value ? ' is-active' : ''), text: option.label });
        btn.addEventListener('click', function () { filter = option.value; render(); });
        return btn;
      }).concat([
        el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Очистить список', onclick: function () {
          if (!window.confirm('Удалить все ошибки из списка?')) return;
          Store.state.wrong = []; Store.save(); render();
        } })
      ])));

      if (!wrong.length) {
        host.appendChild(EE.emptyState('Ошибок нет', 'Ошибки появляются, когда ответ неверный. Реши раунд в тренажёре, чтобы проверить себя.'));
        return;
      }
      var list = el('div', { class: 'error-list' });
      wrong.forEach(function (item) {
        list.appendChild(el('article', { class: 'error-card' }, [
          el('div', { class: 'error-head' }, [
            EE.badge(EE.examLabel(item.exam), EE.examTone(item.exam)),
            EE.badge(sectionLabel(item.trainer), 'neutral'),
            el('small', { text: new Date(item.at).toLocaleString('ru-RU') })
          ]),
          el('b', { text: item.prompt }),
          el('div', { class: 'error-answers' }, [
            el('span', { class: 'is-wrong', text: 'Твой ответ: ' + item.given }),
            el('span', { class: 'is-right', text: 'Верно: ' + item.answer })
          ]),
          el('p', { class: 'hint', text: item.explanation }),
          el('div', { class: 'error-actions' }, [
            el('a', { class: 'btn btn-secondary btn-sm', href: './' + pageOf(item.trainer), text: 'Повторить в тренажёре' }),
            el('button', { type: 'button', class: 'btn btn-ghost btn-sm', text: 'Убрать', onclick: function () {
              Store.state.wrong = Store.state.wrong.filter(function (entry) { return entry.id !== item.id || entry.at !== item.at; });
              Store.save(); render();
            } })
          ])
        ]));
      });
      host.appendChild(list);
    }
    render();
  };

  pages.dictionary = function () {
    var host = mount('dictionary-app');
    if (!host) return;
    dictionaryTrainer(host, Store.state.exam || 'oge');
  };

  pages.account = function () {
    function render() {}
    var importInput = document.querySelector('#backup-file');
    if (importInput) {
      importInput.addEventListener('change', function () {
        var file = importInput.files && importInput.files[0];
        if (!file) return;
        file.text().then(function (content) {
          try {
            var parsed = JSON.parse(content);
            if (!parsed || typeof parsed !== 'object') throw new Error('bad');
            Store.state = parsed;
            Store.save();
            var status = document.querySelector('#backup-status');
            if (status) status.textContent = 'Резервная копия восстановлена в этом браузере.';
          } catch (error) {
            var el2 = document.querySelector('#backup-status');
            if (el2) el2.textContent = 'Не удалось прочитать файл: нужен JSON, скачанный на этой странице.';
          }
        });
      });
    }
    var resetBtn = document.querySelector('#reset-progress');
    if (resetBtn) resetBtn.addEventListener('click', function () {
      if (!window.confirm('Удалить весь локальный прогресс на этом устройстве?')) return;
      Store.reset();
      var status = document.querySelector('#backup-status');
      if (status) status.textContent = 'Локальный прогресс сброшен.';
    });
    var exportBtn = document.querySelector('#export-backup');
    if (exportBtn) exportBtn.addEventListener('click', function () {
      var blob = new Blob([JSON.stringify(Store.state, null, 2)], { type: 'application/json' });
      var url = URL.createObjectURL(blob);
      var link = el('a', { href: url, download: 'english-exam-backup-' + todayKey() + '.json' });
      document.body.appendChild(link); link.click(); link.remove();
      window.setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
    });
    render();
  };

  pages.admin = function () {
    var host = mount('admin-local');
    if (!host) return;
    var totals = Store.totals();
    clear(host);
    host.appendChild(el('div', { class: 'stat-grid' }, [
      el('div', { class: 'stat-card' }, [el('span', { text: 'Раундов на устройстве' }), el('b', { text: String(totals.rounds) })]),
      el('div', { class: 'stat-card' }, [el('span', { text: 'Ответов проверено' }), el('b', { text: String(totals.total) })]),
      el('div', { class: 'stat-card' }, [el('span', { text: 'Точность' }), el('b', { text: totals.accuracy === null ? '—' : totals.accuracy + '%' })]),
      el('div', { class: 'stat-card' }, [el('span', { text: 'Ошибок в списке' }), el('b', { text: String(Store.state.wrong.length) })])
    ]));
  };

  pages.library = function () {
    var host = mount('library-filter');
    if (!host) return;
    var input = el('input', { class: 'search', type: 'search', placeholder: 'Поиск по коду или теме', 'aria-label': 'Поиск по темам' });
    host.appendChild(input);
    input.addEventListener('input', function () {
      var query = input.value.trim().toLowerCase();
      Array.prototype.forEach.call(document.querySelectorAll('[data-topic-row]'), function (row) {
        var haystack = (row.getAttribute('data-topic-row') || '').toLowerCase();
        row.hidden = Boolean(query) && haystack.indexOf(query) === -1;
      });
    });
  };

  pages.streak = function () {};

  EE.pages = pages;

  document.addEventListener('DOMContentLoaded', function () {
    var page = document.body.getAttribute('data-page') || '';
    var key = page.split('-')[0] === 'trainer' ? 'trainer' : page;
    var fn = pages[key];
    if (fn) {
      try { fn(); } catch (error) {
        var host = document.querySelector('[data-mount]');
        if (host) host.appendChild(el('p', { class: 'hint', text: 'Не удалось запустить этот раздел: ' + error.message }));
        if (window.console) console.error(error);
      }
    }
    Array.prototype.forEach.call(document.querySelectorAll('[data-page-key]'), function (node) {
      var fn2 = pages[node.getAttribute('data-page-key')];
      if (fn2) fn2();
    });
  });
})();
